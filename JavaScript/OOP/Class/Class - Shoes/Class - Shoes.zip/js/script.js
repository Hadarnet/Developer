class shoes {
    constructor(name) {
    this.name = name;
    this.availableSize = 36,38,44;
    }
  
    availableShoes(){return this.availableSize = Adidas.availableSize } 


    checkIfHaveMySize(){
            console.log(`${this.name} ${this.availableSize} ${this.availableShoes() ? "This Size Available" : "This Size Not Available"}`);
            
        }
    }





let Adidas = new shoes("Star Shoes");
Adidas.availableSize = 36,38,44;
Adidas.checkIfHaveMySize();

