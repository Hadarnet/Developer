function palindrome(str) {

    var len = str.length;
    if (len === 0 || len === 1){return true;}
    var mid = Math.floor(len/2);
    console.log(mid);

    for ( var i = 0; i < mid; i++ ) {
        if (str[i] !== str[len - 1 - i]) {
            return false;
        }
    }

    return true;
}
	
var expect = require('chai').assert;
var ctranspose = require('./arrays');

describe('arrays Test Block',function(){
	it('for arrays',function(){
		var result = ctranspose.isPalindrome('tat');
		assert(result).to.not.be.undefined;
		assert(result).to.equal(true);
	});
	it('for non palindrome',function(){
		var result = Palindrome.isPalindrome('tata');
		assert(result).to.not.be.undefined;
		assert(result).to.equal(false);
	});
	it('handling of undefined value',function(){
		var str;
		var result = Palindrome.isPalindrome(str);
		assert(result).to.not.be.undefined;
	});
});