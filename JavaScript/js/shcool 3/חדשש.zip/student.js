class Student {
    constructor(name, courses) {
        this.name = name
        this.courses = courses
    }

}