import React, { useState } from 'react';
import './regularColor.css'
import Home from '../home/Home'

export default function regularColor() {
  const [myColor, setColor] = useState();

  var i = 0;
  function oneAfterColor() {
    var doc = document.querySelector("#background");
    var color = [myColor, setColor];
    doc.style.backgroundColor = color[i];
    i = (i + 1) % color.length;
    
  } setInterval(oneAfterColor, 1000);
  
  return (<div id="background"></div>);
   }
   

  //  Limit to four times four seconds color setcolor

   

  

  


  

