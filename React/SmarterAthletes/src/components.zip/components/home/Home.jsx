import React, {useState} from 'react';
import { CirclePicker } from 'react-color';
import { BrowserRouter as Router} from 'react-router-dom'
import Timer from '../timer/Timer'
import {Link} from 'react-router-dom'


export default function Home() {
  const [myColor, setColor] = useState();  

  
  return (
         <div className="circlePicker">
          
        <h1>התאמן איתי בחר שנים צבעים</h1>

         <CirclePicker 
           myColor={myColor}
           onChangeComplete={myColor => {
             setColor(myColor.hex);
           }}
         />
   <Link to='timer/'>
   <button type="button" className="btn btn-info">התחל</button>
   
   </Link>
<div id="background"></div>


       </div>
     );
   }
   
   

  

  


  

