import React, {useState} from 'react';
import Home from '../home/Home'

import './randomColor.css'

export default function randomColor() {
  const [myColor, setColor] = useState();


function randomColorFor() {
  var colory = [myColor, setColor];
  for (var i = 0; i < 6; i++ ) {
  color = colory.floor(Math.random() * 16);
  }
}

  
  return (
     
         

<div id="background"></div>


     );
   }
   
   

  

  


  

