import React from 'react';

export default class Alert extends React.Component {



  
  componentDidMount(){
       alert("I’m alive!")
   }

   
  
   render() {
    return (
      <div>
     </div>
    );
  }
}