import React from 'react';
import './App.css';
import Alert from './components/Alert'

function App() {
  return (
    <div className="App">
     <Alert></Alert>
    </div>
  );
}

export default App;
