var numberbig = prompt("Please enter your Frist Number", "Frist Number");
var numbersmall = prompt("Please enter your Second Number", "Second Number");
num1=parseInt(numberbig)
num2=parseInt(numbersmall)

if (num1>num2){
    console.log(num1/num2)

}

else if (num1==0 || num2==0)
 {console.log(1)}

 else { console.log(num2/num1)
 }

 ////// 

 var input = prompt("Please enter your Number", "Number");
 num3=parseInt(input)
 
 if (num3 .NaN=false){
     num3+=5
     console.log(num3)
 
 }
 else if(num3 .NaN=true){
    console.log(input+"!!!!")

 }
 
  ////// 

  var word1 = prompt("Please enter your word", "word");
  var word2 = prompt("Please enter your word", "word");
  var areEqual = word1.toLowerCase() === word2.toLowerCase();
  console.log(areEqual)

  
  

  
