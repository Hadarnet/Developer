var total = 0
for (var i = 0; i<=100; i++){
    
    total +=i;
    
}
console.log(total)


var sum = 0; 
var i = 0;       

    while (i<=100) {

      sum += i; 
      i++;

    }
    console.log(sum)
/////

var string =  prmot("enter text")
let string2= "";
for(i = string.length -1; i >=0; i--){
  string2 += string[i];
}
console.log(string2)
